package com.example.demo.controller;

import com.example.demo.entity.Post;
import com.example.demo.entity.Comment;
import com.example.demo.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/posts")
public class PostController {

    @Autowired
    private PostService postService;

    @PostMapping
    public ResponseEntity<Post> createPost(@RequestBody Post post) {
        Post createdPost = postService.createPost(post);
        return ResponseEntity.ok(createdPost);
    }

    @PostMapping("/{id}/comments")
    public ResponseEntity<Comment> addCommentToPost(@PathVariable Long id, @RequestBody Comment comment) {
        Comment createdComment = postService.addCommentToPost(id, comment);
        return ResponseEntity.ok(createdComment);
    }

//    @GetMapping("/{id}/comments")
//    public ResponseEntity<Map<String, Object>> getCommentsForPost(@PathVariable Long id) {
//        List<Comment> comments = postService.getCommentsForPost(id);
//        Map<String, Object> response = Map.of(
//            "post_id", id,
//            "comments", comments.stream()
//                .map(comment -> Map.of(
//                    "id", comment.getId(),
//                    "author_id", comment.getAuthor().getId(),
//                    "content", comment.getContent(),
//                    "created_at", comment.getCreatedAt()
//                ))
//                .collect(Collectors.toList())
//        );
//        return ResponseEntity.ok(response);
   // }
}
