package com.example.demo.controller;

import com.example.demo.entity.Order;
import com.example.demo.entity.OrderItem;
import com.example.demo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        Order createdOrder = orderService.createOrder(order);
        return ResponseEntity.ok(createdOrder);
    }

    @PostMapping("/{id}/items")
    public ResponseEntity<Order> addItemToOrder(@PathVariable Long id, @RequestBody OrderItem orderItem) {
        Order updatedOrder = orderService.addItemToOrder(id, orderItem);
        return ResponseEntity.ok(updatedOrder);
    }

    @GetMapping("/{id}/total")
    public ResponseEntity<Map<String, BigDecimal>> getOrderTotal(@PathVariable Long id) {
        Order order = orderService.getOrderById(id);
        BigDecimal totalPrice = order.getTotalPrice();

        Map<String, BigDecimal> response = new HashMap<>();
        response.put("order_id", BigDecimal.valueOf(id));
        response.put("total_price", totalPrice);

        return ResponseEntity.ok(response);
    }
}
