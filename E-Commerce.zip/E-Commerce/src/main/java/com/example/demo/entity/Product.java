package com.example.demo.entity;

import java.math.BigDecimal;
import java.security.Timestamp;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.*;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private BigDecimal price;
    private int stock;
    @CreationTimestamp
    private Timestamp createdAt;
    // Getters and Setters
}