package com.example.demo.controller;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        return productService.addProduct(product);
    }

    @PutMapping("/{id}")
    public Product updateProductQuantity(@PathVariable Long id, @RequestParam Integer quantity) {
        return productService.updateProductQuantity(id, quantity);
    }

//    @GetMapping("/inventory/value")
//    public long getTotalInventoryValue() {
//        return productService.calculateTotalInventoryValue();
//    }
    @GetMapping("/inventory/value")
    public long getTotalInventoryValue() {
        return productService.calculateTotalInventoryValue();
    }
    
    
}
