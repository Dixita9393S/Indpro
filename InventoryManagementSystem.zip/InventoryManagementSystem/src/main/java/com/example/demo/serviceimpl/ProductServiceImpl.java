package com.example.demo.serviceimpl;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Product updateProductQuantity(Long id, Integer quantity) {
        Product product = productRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Product not found"));
        product.setQuantity(quantity);
        return productRepository.save(product);
    }

    @Override
    public long calculateTotalInventoryValue() {
        List<Product> products = productRepository.findAll();
        long totalValue = 0;

        for (Product product : products) {
           
                totalValue += product.getPrice() * product.getQuantity();
            
        }
        
        return totalValue;
    }




}
