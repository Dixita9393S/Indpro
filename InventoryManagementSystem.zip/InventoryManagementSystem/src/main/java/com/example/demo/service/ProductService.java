package com.example.demo.service;

import com.example.demo.entity.Product;
import java.math.BigDecimal;

public interface ProductService {
    Product addProduct(Product product);
    Product updateProductQuantity(Long id, Integer quantity);
    long calculateTotalInventoryValue();
}
